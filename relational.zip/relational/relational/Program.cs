﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace relational
{
    class Program
    {
        static void Main(string[] args)
        {
            bool result;
            int a = 10, b = 20;
            result = (a == b);
            Console.WriteLine("Equal to Operator: " + result);
            result = (a > b);
            Console.WriteLine("Greater than Operator: " + result);
            result = (a <= b);
            Console.WriteLine("Lesser than or Equal to: " + result);
            result = (a != b);
            Console.WriteLine("Not Equal to Operator: " + result);
            Console.ReadLine();
        }
    }
}
