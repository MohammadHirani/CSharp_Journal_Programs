﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace logicalop
{
    class Program
    {
        static void Main(string[] args)
        {
            string name, password;

            name = "Mohammad";
            password = "Mohammad123";

            
            if (name == "Mohammad" && password == "Mohammad123")
            {
                Console.WriteLine("Login Successful");
            }
            else
            {
                Console.WriteLine("Unauthorised access");
            }
            Console.ReadLine();
        }
    }
}
