﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace one_D_array
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] sub = new string[5];
            sub[0] = "C#";
            sub[1] = "Java";
            sub[2] = "networking";
            sub[3] = "os";

            Console.WriteLine("subjects of SYBCA 4 semester is :\n\n");

            int i = 0;
            Console.Write("\t1\t2\t3\t4\n\n\n\t");
            for (i = 0; i < 4; i++)
            {
                Console.Write("{0}\t", sub[i]);
            }
            Console.Read();
        }
    }
}
