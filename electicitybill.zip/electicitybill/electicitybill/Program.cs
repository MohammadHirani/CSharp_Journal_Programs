﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace electicitybill
{
    class Program
    {
        static void Main(string[] args)
        {
            int oldunit;
            int newunit;
            int cost;
            Console.WriteLine("Enter last unit reading :");
            oldunit = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter new unit reading :");
            newunit = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter your case 1 for rural and 2 for urban");
            int n = Convert.ToInt32(Console.ReadLine());
            int bn;

            if (newunit > oldunit)
            {
                int diff = newunit - oldunit;
                switch (n)
                {  
                    case 1: 
                        if(diff<100)
                        {
                            bn = diff*10;
                            Console.WriteLine("Your due bill costs : " + bn);
                        }
                        else if(100<=diff && diff<=200)
                        {
                            bn = diff * 15;
                            Console.WriteLine("Your due bill costs : " + bn);
                        }
                        else if (200 <= diff && diff <= 300)
                        {
                            bn = diff * 20;
                            Console.WriteLine("Your due bill costs : " + bn);
                        }
                        else if (300 <= diff && diff <= 400)
                        {
                            bn = diff * 25;
                            Console.WriteLine("Your due bill costs : " + bn);
                        }
                        else 
                        {
                            bn = diff * 35;
                            Console.WriteLine("Your due bill costs : " + bn);
                        }
                        break;
                    case 2:
                        if (diff < 100)
                        {
                            bn = diff * 15;
                            Console.WriteLine("Your due bill costs : " + bn);
                        }
                        else if (100 <= diff && diff <= 200)
                        {
                            bn = diff * 20;
                            Console.WriteLine("Your due bill costs : " + bn);
                        }
                        else if (200 <= diff && diff <= 300)
                        {
                            bn = diff * 25;
                            Console.WriteLine("Your due bill costs : " + bn);
                        }
                        else if (300 <= diff && diff <= 400)
                        {
                            bn = diff * 30;
                            Console.WriteLine("Your due bill costs : " + bn);
                        }
                        else
                        {
                            bn = diff * 35;
                            Console.WriteLine("Your due bill costs : " + bn);
                        }
                        break;
                     default:
                        {
                            Console.WriteLine("Kindly choose atlest one from rural or urban!!!");   
                        }
                        break;
                }
                Console.ReadLine();                
            }
        }
    }
}
