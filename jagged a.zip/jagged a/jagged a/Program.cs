﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace jagged_a
{
    class Program
    {
        static void Main(string[] args)
        {
            string[][] str = new string[5][];


            str[0] = new string[5];
            str[1] = new string[10];
            str[2] = new string[20];
           
            str[0][0] = "this is jagged array";

            str[1][0] = "stydy SYBCA";


            str[2][0] = "rajkot";

           


            for (int i = 0; i < 3; i++)

                Console.WriteLine(str[i][0]);
            Console.Read();
        }
    }
}
