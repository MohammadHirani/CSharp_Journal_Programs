﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ele_bill
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             * 100unit = 10rs per unit
             * 200unit = 15rs per unit
             * 400unit = 20rs per unit
             * 600unit = 25rs per unit
             * 800unit = 30rs per unit
             */
            int unit = 0;
            Console.WriteLine("Enter a unit of electricity bil : ");
            unit = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("unit = " + unit.ToString());
            int tot = 0;
            if (unit <= 100)
            {
                tot = unit * 10;
                Console.WriteLine("1. Total Rs. : " + tot);
            }
            else if (unit >= 100 && unit <= 200)
            {
                unit = unit * 15;
                Console.WriteLine("2 .Total Rs. : " + unit);
            }
            else if (unit >= 200 && unit <= 400)
            {
                unit = unit * 20;
                Console.WriteLine("3. Total Rs. : " + unit);
            }
            else if (unit >= 400 && unit <= 600)
            {
                unit = unit * 25;
                Console.WriteLine("4. Total Rs. : " + unit);
            }
            else if (unit >= 600 && unit <= 800)
            {
                unit = unit * 30;
                Console.WriteLine("5. Total Rs. : " + unit);
            }
            else
            {
                unit = unit * 40;
                Console.WriteLine("6. Total Rs. : " + unit);
            }
            Console.Read();
        }
    }
}
