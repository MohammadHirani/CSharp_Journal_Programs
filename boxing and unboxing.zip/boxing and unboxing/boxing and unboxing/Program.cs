﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace boxing_and_unboxing
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = 19;
            object obj = num; // boxing

            int i = (int)obj;// unboxing

            Console.WriteLine("Value of ob object is : " + obj);
            Console.WriteLine("Value of i is : " + i);
            Console.Read();
        }
    }
}
